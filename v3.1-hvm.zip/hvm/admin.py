#!/usr/bin/env python3
"""
license_generator.py

Usage examples:
  # gerar par de chaves (private_key.pem + print PUBLIC_HEX)
  python3 license_generator.py --gen-keys

  # criar licença para machine_id específica por X dias
  python3 license_generator.py --create --machine-id 0x1a2b3c4d5e6f --days 30

  # criar licença com data de expiração específica (ISO YYYY-MM-DD)
  python3 license_generator.py --create --machine-id 0x1a2b3c4d5e6f --expires 2026-01-01T00:00:00

Notes:
 - Usa ecdsa (pip install ecdsa)
 - Formato de saída é exatamente: base64.b64encode(data_bytes + b'||' + signature)
 - Substitua PUBLIC_HEX no seu hvm.py pelo valor impresso por --gen-keys
"""

import argparse
import json
import base64
import datetime
from ecdsa import SigningKey, VerifyingKey, NIST384p

PRIVATE_KEY_FILE = "private_key.pem"
PUBLIC_KEY_HEX_FILE = "public_key.hex"

def gen_keys(save_private=True):
    sk = SigningKey.generate(curve=NIST384p)
    vk = sk.get_verifying_key()
    if save_private:
        with open(PRIVATE_KEY_FILE, "wb") as f:
            f.write(sk.to_pem())
        with open(PUBLIC_KEY_HEX_FILE, "w") as f:
            f.write(vk.to_string().hex())
    return sk, vk

def load_private_key(path=PRIVATE_KEY_FILE):
    with open(path, "rb") as f:
        pem = f.read()
    sk = SigningKey.from_pem(pem)
    return sk

def create_license(sk, machine_id, expires_iso, extra=None):
    """
    sk: SigningKey
    machine_id: string (e.g. hex(uuid.getnode()) or whatever your app expects)
    expires_iso: string in ISO format: YYYY-MM-DD or YYYY-MM-DDTHH:MM:SS
    extra: dict for extra fields (optional)
    returns: base64-encoded license token (str)
    """
    license_data = {
        "machine_id": machine_id,
        "expires": expires_iso,
        "issued": datetime.datetime.utcnow().isoformat() + "Z"
    }
    if extra:
        license_data.update(extra)
    data_b = json.dumps(license_data, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    signature = sk.sign(data_b)
    token = base64.b64encode(data_b + b"||" + signature).decode("utf-8")
    return token, license_data

def main():
    parser = argparse.ArgumentParser(description="License generator for HVM-style validate_license()")
    parser.add_argument("--gen-keys", action="store_true", help="Generate a new ECDSA keypair and save private_key.pem + public_key.hex")
    parser.add_argument("--create", action="store_true", help="Create a license token using private_key.pem")
    parser.add_argument("--machine-id", type=str, help="Machine ID stored inside license (e.g. hex uuid)")
    parser.add_argument("--days", type=int, default=30, help="Validity in days (alternative to --expires)")
    parser.add_argument("--expires", type=str, help="Expiration in ISO format (YYYY-MM-DD or full ISO)")
    parser.add_argument("--private-key", type=str, default=PRIVATE_KEY_FILE, help="Path to private key PEM")
    parser.add_argument("--show-public", action="store_true", help="Print public key hex (vk.to_string().hex())")
    parser.add_argument("--extra", type=str, help="JSON string with extra fields to include")
    args = parser.parse_args()

    if args.gen_keys:
        sk, vk = gen_keys(save_private=True)
        print("Generated keys.")
        print(f"Private key saved to {PRIVATE_KEY_FILE}")
        print(f"Public hex saved to {PUBLIC_KEY_HEX_FILE}")
        print("PUBLIC_HEX (paste this into your hvm.py):")
        print(vk.to_string().hex())
        return

    if args.show_public:
        try:
            with open(PUBLIC_KEY_HEX_FILE, "r") as f:
                print(f.read().strip())
        except FileNotFoundError:
            print("No public_key.hex found. Run --gen-keys first.")
        return

    if args.create:
        if not args.machine_id:
            print("Error: --machine-id is required to create a license")
            return
        if args.expires:
            expires_iso = args.expires
        else:
            expires_dt = datetime.datetime.utcnow() + datetime.timedelta(days=args.days)
            expires_iso = expires_dt.isoformat()
        try:
            sk = load_private_key(args.private_key)
        except Exception as e:
            print(f"Cannot load private key from {args.private_key}: {e}")
            return

        extra = None
        if args.extra:
            try:
                extra = json.loads(args.extra)
            except Exception as e:
                print(f"Invalid --extra JSON: {e}")
                return

        token, data = create_license(sk, args.machine_id, expires_iso, extra=extra)
        print("License token (give this to the client / paste into license input):")
        print(token)
        print("\nLicense JSON content (for your reference):")
        print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    parser.print_help()

if __name__ == "__main__":
    main()
